post = 10
print(f"Начальное значение: post = {post}")

post -= 1
print(f"После операции -=1: post = {post}")

post += 11
print(f"После операции +=11: post = {post}")

post //= -1
print(f"После операции //= -1: post = {post}")

post *= -11
print(f"После операции *= -11: post = {post}")
