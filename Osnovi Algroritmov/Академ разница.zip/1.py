q = 70
add = -0.916
letter = 'L'

print(f"q = {q}")
print(f"add = {add}, letter = {letter}")
